import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
import java.util.*;

public class PuzzleJava{
    public static void main(String[] args){
        printArr();
        shuffleAndPrint();
        shuffleAndDisplay();
        randomTen();
        randomAndSort();
        System.out.println(randomString());
        tenRandom();
    }
    //Prints the sum and return numbers greater than 10
    public static void printArr(){
        
        ArrayList<Integer> numbers = new ArrayList<Integer>();
        ArrayList<Integer> newArr = new ArrayList<Integer>();
        numbers.add(3);
        numbers.add(5);
        numbers.add(1);
        numbers.add(2);
        numbers.add(7);
        numbers.add(9);
        numbers.add(8);
        numbers.add(13);
        numbers.add(25);
        numbers.add(32);
        System.out.println(numbers.size());
        int index, sum=0;
        for(index=0; index<numbers.size(); index++){
             sum = sum+numbers.get(index);
             if(numbers.get(index)>10){
                 newArr.add(numbers.get(index));
             }
         }
        System.out.println(sum);
        System.out.println(newArr);
    }
    //Shuffle and print
    public static void shuffleAndPrint(){
        ArrayList<String> names = new ArrayList<String>();
        ArrayList<String> newList = new ArrayList<String>();
        names.add("Nancy");
        names.add("Jinichi");
        names.add("Fujibayashi");
        names.add("Momochi");
        names.add("Ishikawa");
        //int index;
        Collections.shuffle(names);
        System.out.println(names);
        int index;
        for(index=0; index<names.size(); index++){
            if(names.get(index).length()>5){
                newList.add(names.get(index));
            }
        }
        System.out.println(newList);

    }
    //Shuffle and display  first and last letter of the array
    public static void shuffleAndDisplay(){
        ArrayList<String> alphabets = new ArrayList<String>();
        alphabets.add("a");
        alphabets.add("b");
        alphabets.add("c");
        alphabets.add("d");
        alphabets.add("e");
        alphabets.add("f");
        alphabets.add("g");
        alphabets.add("h");
        alphabets.add("i");
        alphabets.add("j");
        alphabets.add("k");
        alphabets.add("l");
        alphabets.add("m");
        alphabets.add("n");
        alphabets.add("o");
        alphabets.add("p");
        alphabets.add("q");
        alphabets.add("r");
        alphabets.add("s");
        alphabets.add("t");
        alphabets.add("u");
        alphabets.add("v");
        alphabets.add("w");
        alphabets.add("x");
        alphabets.add("y");
        alphabets.add("z");
        Collections.shuffle(alphabets);
        System.out.println(alphabets.get(alphabets.size()-1));
        //System.out.println(alphabets.get(0));
        String letter = alphabets.get(0);
        if(letter == "a" || letter == "e" || letter == "i" || letter == "o"|| letter == "u" ){
            System.out.println("A vowel");
        }
        else {
            System.out.println(alphabets.get(0));
        }
    }
    //Generate and return with 10 random numbers between 55-100
    public static void randomTen(){
        Random r = new Random();
        int index;
        int[] newArr = new int[10];
        for(index=0; index<newArr.length; index++){
            newArr[index]=r.nextInt((100-55)+1) + 55;
        }
        System.out.println(Arrays.toString(newArr));
    }
    //Generate and return array with 10 random numbers between 55-100 and sort it.
    public static void randomAndSort(){
        Random r = new Random();
        int index;
        ArrayList<Integer> newarr = new ArrayList<Integer>();
        
        for(index=0; index<10; index++){
            newarr.add(r.nextInt((100-55)+1) + 55);
           
        }
        int max=newarr.get(0), min=newarr.get(0);
        for(int i=0; i<10; i++){
            if(newarr.get(i)>max){
                max=newarr.get(i);
            }
            if(newarr.get(i)<min){
                min=newarr.get(i);
            }
        }
       // Collections.sort(newArr);
        System.out.println(newarr);
        Collections.sort(newarr);
        System.out.println(newarr);
        System.out.println( max);
        System.out.println( min);
    } 
    //random string 5 chacters long
    public static String randomString(){
        Random rand = new Random();
        String alphabet = "0123456789abcdefghijklmnopqrstuvwxyz";
        StringBuilder sb = new StringBuilder();
        int count = 5;
        for(int index=1; index<=count; index++){
            sb.append(alphabet.charAt(rand.nextInt(alphabet.length())));
        }  
        return sb.toString();
    }
    //10 random strings each 5 characters long
    public static void tenRandom(){
        Random rand = new Random();
        ArrayList<String> newarr = new ArrayList<String>();
        String alphabet = "0123456789abcdefghijklmnopqrstuvwxyz";
        StringBuilder sb = new StringBuilder();
        int count = 5, x;
        
            for(int index=1; index<=count; index++){
                for(x=0; x<10; x++){
                String.format("\n");
                sb.append(alphabet.charAt(rand.nextInt(alphabet.length())));
                }
            }
            newarr.add(sb.toString());
        System.out.println(newarr);
    }
}