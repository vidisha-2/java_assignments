package com.codingdojo.bankaccountassignment;

public class BankAccountTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BankAccount a = new BankAccount(299.0,381.0);
		BankAccount b = new BankAccount(1000.00, 500.00);
		a.displayAccountNumber();
		System.out.println("Savings Balance: "+a.getSavingsBalance());
//		a.withdrawMoney(81.0);
//		System.out.println("Checking Balance: "+a.getCheckingBalance());
//		a.withdrawMoney(300.0);
//		System.out.println("Checking Balance: "+a.getCheckingBalance());
		System.out.println(a.getBankFunds());
		System.out.println(BankAccount.getNumberOfAccounts());

}
}
