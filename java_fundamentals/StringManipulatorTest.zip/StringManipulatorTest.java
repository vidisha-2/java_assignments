public class StringManipulatorTest{
    public static void main(String[] args){
        StringManipulator manipulator = new StringManipulator();
        //Trim and Concat
        String result = manipulator.trimAndConcat("  Hello  ","  World  ");
        System.out.println(result);

        //Find the pos of given letter in the string
        char letter ='m';
        System.out.println(manipulator.getIndexOrNull("Coding", letter));

        //Find the pos of a substring in the string
        String word = "Hello";
        String subString = "llo";
        String notSubString = "world";
        System.out.println(manipulator.getIndexOrNull(word, subString));
        System.out.println(manipulator.getIndexOrNull(word, notSubString));

        //Find the substring and concat it with othr string
        String qword = manipulator.concatSubstring("Hello", 1, 2, "world");
        System.out.println(qword);
    }
}