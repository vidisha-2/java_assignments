//import java.util.ArrayList;

public class BasicJavaTest{
    public static void main(String[] args){
        BasicJava myobj = new BasicJava();
       /* myobj.print();
        myobj.oddNum();
        myobj.sum();

        int[] arr = {1,3,5,7,9,13};
        myobj.iterateThrough(arr);

        int[] newarr = {-1,0,8,-3,9};
        myobj.maxOfArray(newarr);

        int[] avgarr = {2,10,3};
        myobj.findAverage(avgarr);

        myobj.arrayWithOddNumbers();

        int[] array1 = {1,3,5,7};
        myobj.greaterThanY(array1, 3);*/
        ///ArrayList<Integer> array3 = new ArrayList<Integer>();
        int[] array2 = {1,5,10,-2};
        myobj.squareValue(array2);

        int[] array3 = {1,5,10,-2};
        //myobj.replaceNegative(array3);

        //myobj.maxMinAvg(array3);
        myobj.shiftVal(array3);
    }
}