
public class PhoneTester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		IPhone iphonexs = new IPhone("X", 100, "AT&T", "Zing");
		Galaxy s9 = new Galaxy("S9", 99, "Verizon", "Ring Ring Ring!");
		iphonexs.displayInfo();
		System.out.println(iphonexs.ring());
		System.out.println(iphonexs.unlock());
		s9.displayInfo();
		System.out.println(s9.ring());
		System.out.println(s9.unlock());
	}

}
