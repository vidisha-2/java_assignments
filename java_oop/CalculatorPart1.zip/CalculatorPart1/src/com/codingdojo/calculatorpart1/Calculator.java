package com.codingdojo.calculatorpart1;

public class Calculator {
	private double operandOne;
	private double operandTwo;
	private String operation;
	private double result;
	//zero argument constructor
	public Calculator() {}
	
	//getters and setters
	public double getOperandOne() {
		return operandOne;
	}
	public void setOperandOne(double operandOne) {
		this.operandOne = operandOne;
	}
	public double getOperandTwo() {
		return operandTwo;
	}
	public void setOperandTwo(double operandTwo) {
		this.operandTwo = operandTwo;
	}

	public String getOperation() {
		return operation;
	}

	public void setOperation(String operation) {
		this.operation = operation;
	}
	
	public double performOperation() {
		switch(this.getOperation()) {
		case "+" : result=this.getOperandOne()+this.operandTwo;
					break;
		case "-" : result=this.getOperandOne()-this.operandTwo;
					break;
		}
		return result;
	}
	public void getResults() {
		System.out.println(result);
	}
}
