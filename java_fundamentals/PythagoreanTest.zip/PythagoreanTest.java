public class PythagoreanTest{
    public static void main(String[] args) {
        Pythagorean obj = new Pythagorean();
        Double getValue = obj.calculateHypotenuse(3,4);
        System.out.println(getValue);
    }
}