
public class Bat extends Mammal {
	public void fly() {
		System.out.println("zzz ");
		int currentEnergy=this.getEnergyLevel();
		currentEnergy-=50;
		this.setEnergyLevel(currentEnergy);
		}
	public void eatHumans() {
		System.out.println("so- well, never mind");
		int currentEnergy=this.getEnergyLevel();
		currentEnergy+=25;
		this.setEnergyLevel(currentEnergy);
	}
	public void attackTown() {
		System.out.println("Onn fire");
		int currentEnergy=this.getEnergyLevel();
		currentEnergy-=100;
		this.setEnergyLevel(currentEnergy);
	}
}
