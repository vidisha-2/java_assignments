public class ListTester{
    public static void main(String[] args){
        SinglyLinkedList sll = new SinglyLinkedList();
        sll.add(3);
        sll.add(5);
        //sll.remove();
        sll.printValue();
    }
}