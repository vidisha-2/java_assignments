public class Project{
    private String name;
    private String description;
    private double initialCost;
    public Project(){
        this.name = "Java";
        this.description= "API's";
        this.inititalCost= "20.0";
    }
    public Project(String name){
        this.name=name;
    }
    public Project(String name, String description){
        this.name=name;
        this.description=description;
    }
    //getter
    public String getName(){
        return name;
    }
    //setter
    public void setName(String name){
        this.name = name;
    }
    //getter
    public String getInitialCost(){
        return initialCost;
    }
    //setter
    public void setInitialCost(double cost){
        this.initialCost = cost;
    }
    //getter
    public String getDescription(){
        return description;
    }
    //setter
    public void setDescription(String description){
        this.description = description;
    }
    public String elevatorPitch(){
        return name +(initialCost) +":"+ description;
    }
}