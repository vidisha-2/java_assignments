
public class Samurai extends Human{
	public static int count;
	public Samurai() {
		this.health=200;
		count++;
	}
	public void deathBlow(Human h)
	{
		h.health=0;
		this.health-=this.health/2;
	}
	public void meditate() {
		this.health+=this.health/2;
	}
	public int howMany() {
		return count;
	}
}
