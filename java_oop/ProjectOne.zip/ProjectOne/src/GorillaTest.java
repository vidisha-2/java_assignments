
public class GorillaTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Gorilla g = new Gorilla();
		g.throwSomething("Banana");
		g.throwSomething("Bat");
		g.throwSomething("Ball");
		g.eatBananas();
		g.eatBananas();
		g.climb();
		g.displayEnergy();
	}

}
