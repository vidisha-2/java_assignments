
public class HumanTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Human h = new Human();
		Wizard wiz = new Wizard();
		Ninja turtle = new Ninja();
		Samurai sam = new Samurai();
		Samurai sam1 = new Samurai();
		System.out.println("Wizard Health: "+wiz.getHealth());
		System.out.println("Ninja Health: "+turtle.getHealth());
		System.out.println("Samurai Health: "+sam.getHealth());
		System.out.println("Samurai count: "+sam.howMany());
	}

}
