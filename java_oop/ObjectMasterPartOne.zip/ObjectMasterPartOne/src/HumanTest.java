
public class HumanTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Human h = new Human();
		Human h3 = new Human();
		h.attack(h3);
		System.out.println(h3.getHealth());
	}

}
