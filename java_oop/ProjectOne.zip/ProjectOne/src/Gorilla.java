
public class Gorilla extends Mammal {

	public void throwSomething(String something) {
		System.out.println("Thrown a "+something);
		int currentEnergy=this.getEnergyLevel();
		currentEnergy-=10;
		this.setEnergyLevel(currentEnergy);
		}
	public void eatBananas() {
		System.out.println("I ate Banana");
		int currentEnergy=this.getEnergyLevel();
		currentEnergy+=10;
		this.setEnergyLevel(currentEnergy);
	}
	public void climb() {
		System.out.println("I climbed");
		int currentEnergy=this.getEnergyLevel();
		currentEnergy-=10;
		this.setEnergyLevel(currentEnergy);
	}
}
