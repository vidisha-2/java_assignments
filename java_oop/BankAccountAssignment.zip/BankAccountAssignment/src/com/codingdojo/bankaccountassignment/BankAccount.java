package com.codingdojo.bankaccountassignment;
import java.util.Random;

public class BankAccount {
	private String accountNumber;
	private double checkingBalance;
	private double savingsBalance;
	private static int numberOfAccounts=0;
	public static double totalAmount=0.0;
	
	public BankAccount(double checkMoney, double saveMoney) {
		this.checkingBalance=checkMoney;
		this.savingsBalance=saveMoney;
		numberOfAccounts++;
		this.accountNumber=accNumber();
		totalAmount += this.checkingBalance+this.savingsBalance;
	}
	public double getCheckingBalance() {
		return checkingBalance;
	}
	public void setCheckingBalance(double checkingBalance) {
		this.checkingBalance = checkingBalance;
	}
	public double getSavingsBalance() {
		return savingsBalance;
	}
	public void setSavingsBalance(double savingsBalance) {
		this.savingsBalance = savingsBalance;
	}
	
	public static int getNumberOfAccounts() {
		return numberOfAccounts;
	}
	public void depositMoneyInCheckingAccount(double money) {
		this.checkingBalance+=money;
		totalAmount+=this.checkingBalance;
	}
	public void depositMoneyInSavingAccount(double money) {
		this.savingsBalance+=money;
		totalAmount+=this.savingsBalance;
	}
	private String accNumber() {
		Random r = new Random();
		String newString = "";
		for(int index=0; index<10;index++) {
			int num = r.nextInt(9);
			newString+=Integer.toString(num);
			
		}
		return newString;
	}
	public void withdrawMoney(double money) {
		
		if (this.checkingBalance>money) {
			totalAmount-=money;
			this.checkingBalance -= money;
		}
		else {
			System.out.println("Insufficient Funds");
		}
		
	}
	public void totalBalance() {
		double balance = this.checkingBalance+this.savingsBalance;
		System.out.println("Balance: "+balance);
	}
	public void displayAccountNumber() {
		System.out.println(this.accountNumber);
	}
	public static double getBankFunds() {
		return totalAmount;
	}
}
