import java.util.ArrayList;
import java.util.*;
public class BasicJava{
    //Print 1-255
    public void print(){
        int index;
        for(index=1; index<=255; index++){
            System.out.println(index);
        }

    }
    //Print odd numbers between 1-255
    public void oddNum(){
        int index;
        for(index=1; index<=255; index++){
            if(index%2!=0){
                System.out.println(index);
            }
        }
    }
    //Print Sum
    public void sum(){
        int index, sum=0;
        for(index=0; index<=255; index++){
            sum+=index;
            System.out.format("New number:%d, Sum:%d\n", index,sum);
        }
    }
    //Iterating through an array
    public void iterateThrough(int[] arr){
        int index;
        for(index=0; index<arr.length; index++){
            System.out.println(arr[index]);
        }
    }
    //Find Max
    public void maxOfArray(int[] arr){
        int index, max=arr[0];
        for(index=0; index<arr.length; index++){
            if(max<arr[index]){
                max=arr[index];
            }
        }
        System.out.println(max);
    }
    //Get Average
    public void findAverage(int[] arr){
        int index, sum=0, avg=0;
        for(index=0; index<arr.length; index++){
            sum=sum+arr[index];
        }
        avg = sum/arr.length;
        System.out.println(avg);
    }
    //Array with Odd Numbers
    public void arrayWithOddNumbers(){
        ArrayList<Integer> myarr = new ArrayList<Integer>();
        int index;
        for (index=1; index<=255; index++){
            if(index%2!=0){
                myarr.add(index);
            }
        }
        System.out.println(myarr);
    }
    //Greater Than Y
    public void greaterThanY(int[] arr, int num){
        int index, count=0;
        for(index=0; index<arr.length; index++){
            if(arr[index]>num){
                count=count+1;
            }
        }
        System.out.println(count);
    }
    //Square the values
    public void squareValue(int[] arr){
        int index;
        for(index=0; index<arr.length; index++){
            arr[index]=arr[index]*arr[index];
        }
        //int[] result = Arrays.toString(arr);
        System.out.println( Arrays.toString(arr));
    }
    //Eliminate Negative Numbers
    public void replaceNegative(int[] arr){
        int index;
        for(index=0; index<arr.length; index++){
            if(arr[index]<0){
                arr[index]=0;
            }
        }
       System.out.println( Arrays.toString(arr));
    }
    //Max,Min and Avg
    public void maxMinAvg(int[] arr){
        int index, max=arr[0], min=arr[0], sum=0, avg=0;
        for(index=0; index<arr.length; index++){
            sum = sum+arr[index];
            if(max<arr[index]){
                max= arr[index];
            }
            if(min>arr[index]){
                min= arr[index];
            }
        }
        avg = sum/arr.length;
        int[] newarr = new int[3];
        newarr[0]=max;
        newarr[1]=min;
        newarr[2]=avg;
        System.out.println(Arrays.toString(newarr));
    }
    //Shifting the Value
    public void shiftVal(int[] arr){
        int index;
        for(index=0; index<arr.length-1; index++){
            arr[index]=arr[index+1];
        }
        arr[arr.length-1]=0;
        System.out.println(Arrays.toString(arr));
    }
}