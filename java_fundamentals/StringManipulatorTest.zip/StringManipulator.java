public class StringManipulator{
    public String trimAndConcat(String string1, String string2){
        //string1.trim();
        //string2.trim();
        return string1.trim().concat(string2.trim());

    }
    public Integer getIndexOrNull(String string1, char letter){
        String strg = string1;
        int pos = strg.indexOf(letter);
        if(pos==-1){
            return null;
        }
        else{
        return pos;}
    }
    public Integer getIndexOrNull(String string1, String string2){
        String word = string1;
        String subString = string2;
        int pos = word.indexOf(subString);
         if(pos==-1){
            return null;
        }
        else{
        return pos;}

    }
    public String concatSubstring(String string1, int x, int y, String string2){
        String word = string1;
        String subString = string2;
        String result = word.substring(x,y);  
        return result.concat(subString);
    }
}