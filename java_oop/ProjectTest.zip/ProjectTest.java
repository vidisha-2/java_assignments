public class ProjectTest{
    public static void main(String[] args){
        Project prj = new Project();
        Project xprj = new Project();
        //System.out.println(xprj.name);
        prj.setName("Python");
        prj.setDescription("My new favorite");
        String projectName = prj.getName();
        String projectDesc = prj.getDescription();
        System.out.println("Project- Name:"+projectName+", Description:"+projectDesc);
        System.out.println(prj.elevatorPitch());
    }
}