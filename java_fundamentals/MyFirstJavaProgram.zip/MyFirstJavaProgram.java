public class MyFirstJavaProgram{
    public static void main(String[] args) {
        System.out.println("My name is Vidisha");
        System.out.println("I am 30 years old");
        System.out.println("My hometown is Delhi,India");
    }
} 