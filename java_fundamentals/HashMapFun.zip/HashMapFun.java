import java.util.*;
public class HashMapFun{
    public static void main(String[] args){
        HashMap<String, String> tracklist = new HashMap<String, String>();
        tracklist.put("Perfect","I found a love for me,Darling just dive right in,And follow my lead, Well I found a girl beautiful and sweet,I never knew you were the someone waiting for me,'Cause we were just kids when we fell in love");
        tracklist.put("Woh Ladki","Ek sawari si ladki bawari si, gusse mein patte si kaanpti si, Jo mera jikar sune door se bhi,Tarkeebon se dil ho dhaanpti si");
        tracklist.put("Explosions", "You trembled like you'd seen a ghost, And I gave in, I lack the things you need the most,You said where have you been, You wasted all that sweetness to run and hide");
        tracklist.put("Bad day", "Where is the moment when we needed the most? You kick up the leaves, and the magic is lost,They tell me your blue sky's faded to gray,They tell me your passion's gone away");
        String lyrics = tracklist.get("Perfect");
        System.out.println(lyrics);
        Set<String> keys = tracklist.keySet();
        for(String title : keys){
            System.out.println(title);
            System.out.println(tracklist.get(title));

        }
    }
}