public class FizzBuzzTest{
    public static void main(String[] args) {
        FizzBuzz obj = new FizzBuzz();
        String dis = obj.fizzBuzz(4);
        System.out.println(dis);
        //System.out.println(obj.fizzBuzz(4));


        
    }
}